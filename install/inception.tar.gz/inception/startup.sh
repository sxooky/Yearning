nohup ./bin/Inception ./inc.cnf &
